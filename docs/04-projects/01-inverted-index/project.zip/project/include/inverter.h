#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

string build_inverted_index(string filename);
